/*
 * =====================================================================
 *  SIMPLE LASER TAG  -  Version 1 (starter build)
 * =====================================================================
 *
 *  WHAT THIS DOES
 *  --------------
 *  Each "blaster" is one Arduino. When you pull the trigger it fires an
 *  invisible infrared (IR) beam, just like a TV remote. Every blaster
 *  also has an IR receiver that listens for shots from OTHER players.
 *
 *    - Pull trigger  -> blaster fires an IR "shot" that carries your
 *                       player number.
 *    - Get hit       -> you lose 1 life, the buzzer beeps, and one of
 *                       your life LEDs turns off.
 *    - 0 lives left  -> GAME OVER. Your blaster stops firing and plays
 *                       a sad sound. Press the Arduino's RESET button
 *                       to start again.
 *
 *  NOTE: It's "laser" tag in name only - we use infrared light, not a
 *  real laser. IR is safe for eyes and is what real laser tag uses.
 *
 * ---------------------------------------------------------------------
 *  PARTS (for ONE blaster - build two to play!)
 * ---------------------------------------------------------------------
 *   1x Arduino Uno or Nano
 *   1x IR LED (940nm)            - the "gun barrel"
 *   1x 100 ohm resistor          - for the IR LED
 *   1x IR receiver module (38kHz, e.g. TSOP38238 or VS1838B)
 *   1x Push button               - the trigger
 *   1x Passive or active buzzer  - sound effects
 *   3x Regular LEDs (any color)  - show how many lives you have
 *   3x 220 ohm resistors         - one for each life LED
 *   Jumper wires + breadboard
 *
 * ---------------------------------------------------------------------
 *  WIRING
 * ---------------------------------------------------------------------
 *   IR LED:        long leg (+) -> 100 ohm resistor -> Pin 3
 *                  short leg (-) -> GND
 *                  (Pin 3 MUST be used on an Uno/Nano - the IR
 *                   library uses a hardware timer tied to that pin.)
 *
 *   IR RECEIVER:   OUT -> Pin 2
 *                  GND -> GND
 *                  VCC -> 5V
 *                  (Check your module's pin order! It's printed on the
 *                   board or in its datasheet - they are not all alike.)
 *
 *   TRIGGER:       one side -> Pin 4
 *                  other side -> GND
 *                  (No resistor needed - we turn on the Arduino's
 *                   built-in "pull-up" resistor in the code.)
 *
 *   BUZZER:        (+) -> Pin 5
 *                  (-) -> GND
 *
 *   LIFE LEDs:     Pin 6 -> 220 ohm -> LED long leg, short leg -> GND
 *                  Pin 7 -> 220 ohm -> LED long leg, short leg -> GND
 *                  Pin 8 -> 220 ohm -> LED long leg, short leg -> GND
 *
 * ---------------------------------------------------------------------
 *  LIBRARY YOU NEED TO INSTALL
 * ---------------------------------------------------------------------
 *   In Arduino IDE:  Tools -> Manage Libraries...
 *   Search "IRremote" and install the one by "shirriff, z3t0, ArminJo"
 *   (version 4.x).
 *
 * ---------------------------------------------------------------------
 *  BEFORE UPLOADING TO EACH BLASTER
 * ---------------------------------------------------------------------
 *   Change MY_PLAYER_ID below so every blaster has a DIFFERENT number.
 *   Blaster #1 -> 1, Blaster #2 -> 2, and so on.
 * =====================================================================
 */


// ---------------------------------------------------------------------
//  STEP 1: SETTINGS YOU CAN CHANGE
// ---------------------------------------------------------------------
// "const" means "this value never changes while the program runs".
// Putting all the settings up here makes them easy to find and tweak.

const uint8_t MY_PLAYER_ID     = 1;    // <-- CHANGE THIS for each blaster (1-255)
const uint8_t STARTING_LIVES   = 3;    // how many hits you can take
const unsigned long FIRE_COOLDOWN_MS   = 500;   // wait time between shots (0.5 sec)
const unsigned long HIT_PROTECTION_MS  = 1500;  // after being hit, you can't be hit
                                                // again for this long (1.5 sec)

// This is a "secret code" that every blaster puts in its shots.
// It lets us ignore random IR signals, like a TV remote in the room.
// All blasters in the same game must use the same number.
const uint16_t GAME_CODE = 0x1A;


// ---------------------------------------------------------------------
//  STEP 2: PIN NUMBERS
// ---------------------------------------------------------------------
// Giving pins names means we write "TRIGGER_PIN" instead of "4" in the
// code, which is much easier to read. If you rewire, change it here.

#define IR_SEND_PIN 3          // IR LED (must be defined BEFORE the library
                               // is included, so the library knows about it)
const uint8_t IR_RECEIVE_PIN = 2;   // IR receiver OUT pin
const uint8_t TRIGGER_PIN    = 4;   // trigger button
const uint8_t BUZZER_PIN     = 5;   // buzzer

// The life LEDs are stored in an "array" (a list). LIFE_LED_PINS[0] is
// pin 6, LIFE_LED_PINS[1] is pin 7, LIFE_LED_PINS[2] is pin 8.
const uint8_t LIFE_LED_PINS[] = {6, 7, 8};
const uint8_t NUM_LIFE_LEDS   = 3;


// ---------------------------------------------------------------------
//  STEP 3: BRING IN THE IR LIBRARY
// ---------------------------------------------------------------------
// The library does the hard work of flashing the IR LED 38,000 times a
// second and decoding signals from the receiver.
#include <IRremote.hpp>


// ---------------------------------------------------------------------
//  STEP 4: GAME VARIABLES (things that CHANGE while playing)
// ---------------------------------------------------------------------

uint8_t lives = STARTING_LIVES;     // current lives left
bool    gameOver = false;           // becomes true when lives hit 0

// millis() is the Arduino's built-in stopwatch: the number of
// milliseconds since the board turned on. We save "timestamps" so we
// can check how much time has passed without stopping the program.
unsigned long lastShotTime = 0;     // when we last fired
unsigned long lastHitTime  = 0;     // when we last got hit

// Used to detect the moment the trigger is FIRST pressed, so holding
// the trigger down doesn't fire over and over (no full-auto... yet!).
bool triggerWasPressed = false;


// =====================================================================
//  setup()  -  runs ONCE when the Arduino powers on or is reset
// =====================================================================
void setup() {
  // Start the Serial Monitor so we can print messages to the computer.
  // Open it with Tools -> Serial Monitor, and set it to 9600 baud.
  Serial.begin(9600);
  Serial.println(F("=== Laser Tag starting ==="));
  Serial.print(F("I am player #"));
  Serial.println(MY_PLAYER_ID);

  // --- Set up the trigger button ---
  // INPUT_PULLUP means the pin reads HIGH normally, and LOW when the
  // button is pressed (because pressing it connects the pin to GND).
  pinMode(TRIGGER_PIN, INPUT_PULLUP);

  // --- Set up the buzzer ---
  pinMode(BUZZER_PIN, OUTPUT);

  // --- Set up the life LEDs ---
  // A "for loop" repeats code. Here it runs 3 times (i = 0, 1, 2),
  // once for each LED.
  for (uint8_t i = 0; i < NUM_LIFE_LEDS; i++) {
    pinMode(LIFE_LED_PINS[i], OUTPUT);
  }
  updateLifeLEDs();   // turn on the right number of LEDs

  // --- Start the IR receiver (listening for shots) ---
  // DISABLE_LED_FEEDBACK stops the library from blinking the
  // Arduino's built-in LED every time it sees an IR signal.
  IrReceiver.begin(IR_RECEIVE_PIN, DISABLE_LED_FEEDBACK);

  // --- Start the IR sender (our gun) ---
  IrSender.begin();

  // Play a happy "ready" sound so you know it's working.
  playStartSound();
  Serial.println(F("Ready! Pull the trigger to fire."));
}


// =====================================================================
//  loop()  -  runs OVER AND OVER, forever, as fast as possible
// =====================================================================
// We split the work into small helper functions so loop() reads like a
// to-do list. Each function is explained further down.
void loop() {
  // If the game is over, do nothing. (Press RESET to play again.)
  if (gameOver) {
    return;   // "return" here means "skip the rest of loop() this time"
  }

  checkTrigger();     // 1. Did the player pull the trigger? Fire!
  checkForHits();     // 2. Did someone's shot hit our receiver?
}


// =====================================================================
//  checkTrigger()  -  fires a shot when the trigger is pulled
// =====================================================================
void checkTrigger() {
  // Read the button. Remember: LOW means PRESSED (because of pull-up).
  bool triggerIsPressed = (digitalRead(TRIGGER_PIN) == LOW);

  // We only want to fire on the moment it goes from "not pressed" to
  // "pressed". This is called detecting a "rising edge".
  bool justPressed = triggerIsPressed && !triggerWasPressed;

  // Remember the button state for next time through loop().
  triggerWasPressed = triggerIsPressed;

  if (!justPressed) {
    return;   // trigger wasn't just pulled, nothing to do
  }

  // Cooldown check: has enough time passed since the last shot?
  // (current time - last shot time) = how long ago we fired.
  if (millis() - lastShotTime < FIRE_COOLDOWN_MS) {
    return;   // too soon! still "reloading"
  }

  fireShot();
}


// =====================================================================
//  fireShot()  -  sends the IR signal
// =====================================================================
void fireShot() {
  lastShotTime = millis();   // remember when we fired

  Serial.println(F("PEW! Shot fired."));

  // Send an IR message using the "NEC" format (a common TV-remote
  // format). An NEC message has two parts:
  //    address -> we use GAME_CODE so others know it's a laser tag shot
  //    command -> we use MY_PLAYER_ID so they know WHO shot them
  // The last number (0) means "don't repeat the message".
  IrSender.sendNEC(GAME_CODE, MY_PLAYER_ID, 0);

  // A quick "pew" sound. tone(pin, frequency, duration in ms).
  tone(BUZZER_PIN, 2000, 50);
}


// =====================================================================
//  checkForHits()  -  listens for shots from other players
// =====================================================================
void checkForHits() {
  // decode() returns true if the receiver has caught a full IR message.
  if (!IrReceiver.decode()) {
    return;   // nothing received, so nothing to do
  }

  // Copy the important parts of the message into easy-to-read names.
  // "auto" lets the compiler figure out the type for us.
  auto protocol = IrReceiver.decodedIRData.protocol;  // what format it was
  uint16_t address = IrReceiver.decodedIRData.address; // should be GAME_CODE
  uint16_t shooter = IrReceiver.decodedIRData.command; // the shooter's ID

  // IMPORTANT: tell the receiver to start listening for the NEXT
  // message. If we forget this, it will never receive again!
  IrReceiver.resume();

  // --- Is this a real laser tag shot? ---
  // Ignore anything that isn't NEC format with our GAME_CODE.
  // (This filters out TV remotes and random IR noise.)
  if (protocol != NEC || address != GAME_CODE) {
    return;
  }

  // --- Did we shoot ourselves? ---
  // Our own beam can bounce off a wall back into our receiver.
  // We don't want that to count, so ignore our own player ID.
  if (shooter == MY_PLAYER_ID) {
    return;
  }

  // --- Are we still protected from the last hit? ---
  // Without this, one trigger pull could register as several hits.
  if (millis() - lastHitTime < HIT_PROTECTION_MS) {
    return;
  }

  // If we got here, it's a real hit!
  takeHit(shooter);
}


// =====================================================================
//  takeHit()  -  what happens when we get tagged
// =====================================================================
void takeHit(uint16_t shooter) {
  lastHitTime = millis();
  lives = lives - 1;   // lose one life

  Serial.print(F("HIT by player #"));
  Serial.print(shooter);
  Serial.print(F("!  Lives left: "));
  Serial.println(lives);

  updateLifeLEDs();    // turn off one LED

  if (lives == 0) {
    // Out of lives - game over.
    gameOver = true;
    Serial.println(F("GAME OVER. Press RESET to play again."));
    playGameOverSound();
  } else {
    // Still alive - play the "ouch" sound.
    playHitSound();
  }
}


// =====================================================================
//  updateLifeLEDs()  -  shows remaining lives on the LEDs
// =====================================================================
// Example with 2 lives: LED 0 = ON, LED 1 = ON, LED 2 = OFF
void updateLifeLEDs() {
  for (uint8_t i = 0; i < NUM_LIFE_LEDS; i++) {
    if (i < lives) {
      digitalWrite(LIFE_LED_PINS[i], HIGH);   // ON
    } else {
      digitalWrite(LIFE_LED_PINS[i], LOW);    // OFF
    }
  }
}


// =====================================================================
//  SOUND EFFECTS
// =====================================================================
// tone(pin, frequency) plays a note. Higher number = higher pitch.
// delay(ms) pauses the program. noTone() stops the sound.
// (Using delay() here is OK because these sounds are short.)

void playStartSound() {
  tone(BUZZER_PIN, 1000); delay(100);
  tone(BUZZER_PIN, 1500); delay(100);
  tone(BUZZER_PIN, 2000); delay(150);
  noTone(BUZZER_PIN);
}

void playHitSound() {
  tone(BUZZER_PIN, 400); delay(200);
  noTone(BUZZER_PIN);
}

void playGameOverSound() {
  tone(BUZZER_PIN, 600); delay(300);
  tone(BUZZER_PIN, 400); delay(300);
  tone(BUZZER_PIN, 200); delay(600);
  noTone(BUZZER_PIN);
}
